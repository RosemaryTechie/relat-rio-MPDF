<?php
require_once '\xampp\php\php.ini';
$mpdf =new \Mpdf\Mpdf();
$stylesheet = file_get_contents('../style.css');

$produtos=[
    [
        'nome' =>'Geladeira',
        'categoria' => 'Eletro domestico',
        'preco' => 6199.00,
        'descricao' => 'Geladeira Eletrolux Cycle Defrost 260l freezer com capacidade 53l duas portas branca'
    ],
    [
        'nome' => 'Forno Eletrico',
        'categoria' => 'Eletro domestico',
        'preco' => 2630.32,
        'descricao' => 'Voltagem 220V capacidade 3 bandeijas Aço inoxidável'
    ],
    [
        'nome' => 'Máquina de lavar',
        'categoria' => 'Eletro domestico',
        'preco' => 2049.00,
        'descricao' => 'Voltagem 110V capacidade 15kg Essential Care com cesto inox Jet&Clean'
    ],
    [
        'nome' => 'Fogão',
        'categoria' => 'Eletro domestico',
        'preco' => 1689.00,
        'descricao' => 'Mesa de vidro time Digital Bivolt Acendemento Automático a Gás'
    ]
];

$html='<h1>Relatório de Produtos em PDF com Mpdf</h1>';
$html.= '<table>';
$html .= '<tr><th>Nome</th><th>Categoria</th><th>Preço</th><th>Descrição</th></tr>';

foreach($produtos as $produto){
    $html .= '<tr>';
    $html .= '<td>' . $produto['nome']."</td>";
    $html .= '<td>' .$produto['categoria']."</td>";
    $html .= '<td>' . number_format($produto['preco'],2,',','.') ."</td>";
    $html .= '<td>' .$produto['descricao']."</td>";
    $html .= '</tr>';
}

$html.= '</table>';

$mpdf -> WriteHTML($html);
$mpdf -> Output();
?>